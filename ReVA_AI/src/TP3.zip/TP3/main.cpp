#include <stdio.h>
#include <iostream>
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"



using namespace std;
using namespace cv;


//Image
Mat src, src2;

//Canny
Mat abs_dst, detected_edges;
Mat grad2;

/// Sobel et laplace
Mat src_gray, grad;
Mat grad_x, grad_y;
Mat abs_grad_x, abs_grad_y;

int scale = 2;
///const int alpha_slider_max = 20;
///int alpha_slider;

int delta = 255;
///const int delta_slider_max = 255;
///int delta_slider;

//highthreshold
const int amax_canny_max = 200;
int amax_canny;

//lowthreshold
const int alpha_canny_max = 100;
int alpha_canny;


//CalculContours
int contours_detecte=0;
int contours_ref = 0;
int contour_correct = 0;
int faux_positif = 0;
int faux_negatif = 0;

double performance = 0 ;
double tfp = 0 ;
double tfn = 0 ;

//pourquoi ils regardent > 240 ?

//255 c'est blanc, un contours est noir donc < 50 ?
int detec(Mat image) {
    int contours = 0;
    for(int y = 0; y < image.rows; y++)
        for(int x = 0; x < image.cols; x++)
            if(image.at<uchar>(y,x)>230)
                contours++;
    return contours;
}

//si contours detecte ? est ce que contours detecter aussi sur src2
int correc(Mat imgcal){
    int intersection = 0;
    
    for(int y = 0; y < imgcal.rows; y++)
        for(int x = 0; x < imgcal.cols; x++)
            if(imgcal.at<uchar>(y,x) > )
               if(src2.at<uchar>(y,x) > )
                intersection++;
    return intersection;
}


void calcul(int val){
    
    contours_detecte=0;
    
    if(val == 1){
        contours_detecte = detec(grad2);
        contour_correct = correc(grad2);
        faux_positif = contours_detecte - contour_correct;
        faux_negatif = contours_ref - contour_correct;
        
        performance = (double) (contour_correct/(contour_correct+faux_negatif+faux_positif));
        tfp = (double) (faux_positif/(contour_correct+faux_negatif+faux_positif));
        tfn = (double) (faux_negatif/(contour_correct+faux_negatif+faux_positif));
        cout<< " Canny CD " << contours_detecte << " CC " << contour_correct << " FP "<< faux_positif << " FN " << faux_negatif << " P " << performance << " TFP " << tfp << " TFN " << tfn << endl;
        
    }
    if (val == 2){
        contours_detecte = detec(abs_dst);
        contour_correct = correc(abs_dst);
        faux_positif = contours_detecte - contour_correct;
        faux_negatif = contours_ref - contour_correct;
        
        performance = (double) (contour_correct/(contour_correct+faux_negatif+faux_positif));
        tfp = (double) (faux_positif/(contour_correct+faux_negatif+faux_positif));
        tfn = (double) (faux_negatif/(contour_correct+faux_negatif+faux_positif));
    
        cout<< " Laplace CD " << contours_detecte << " CC " << contour_correct << " FP "<< faux_positif << " FN " << faux_negatif << " P " << performance << " TFP " << tfp << " TFN " << tfn << endl;
    }
    
    if (val == 3){
        contours_detecte = detec(grad);
        contour_correct = correc(grad);
        faux_positif = contours_detecte - contour_correct;
        faux_negatif = contours_ref - contour_correct;
        
        performance = (double) (contour_correct/(contour_correct+faux_negatif+faux_positif));
        tfp = (double) (faux_positif/(contour_correct+faux_negatif+faux_positif));
        tfn = (double) (faux_negatif/(contour_correct+faux_negatif+faux_positif));
       
        cout<< " Sobel CD " << contours_detecte << " CC " << contour_correct << " FP "<< faux_positif << " FN " << faux_negatif << " P " << performance << " TFP " << tfp << " TFN " << tfn << endl;
    }
    
    
    
}


//void Sobel(InputArray src, OutputArray dst, int ddepth, int dx, int dy, int ksize=3, double scale=1, double delta=0, int borderType=BORDER_DEFAULT )
//dx – order of the derivative x. & dy – order of the derivative y.
void sobel(){
    
    /// Gradient X
    //Scharr( src_gray, grad_x, ddepth, 1, 0, scale, delta, BORDER_DEFAULT );
    Sobel( src_gray, grad_x, CV_16S, 1, 0, 3, scale, delta, BORDER_DEFAULT );
    convertScaleAbs( grad_x, abs_grad_x );
    
    /// Gradient Y
    //Scharr( src_gray, grad_y, ddepth, 0, 1, scale, delta, BORDER_DEFAULT );
    Sobel( src_gray, grad_y, CV_16S, 0, 1, 3, scale, delta, BORDER_DEFAULT );
    convertScaleAbs( grad_y, abs_grad_y );
    
    /// Total Gradient (approximate)
    addWeighted( abs_grad_x, 0.5, abs_grad_y, 0.5, 0, grad );
    
    /*******/
    calcul(3);
    /******/
    
    imshow( "Sobel Demo", grad );
}

void laplace(){

    Laplacian( src_gray, grad, CV_16S, 3, scale, delta, BORDER_DEFAULT );
    convertScaleAbs( grad, abs_dst );
    
    /*************/
    calcul(2);
    /************/
    
    /// Show what you got
    imshow( "Laplace Demo", abs_dst );
}

void canny(){
 
    /// Reduce noise with a kernel 3x3
    GaussianBlur( src_gray, detected_edges, Size(3,3), 0, 0, BORDER_DEFAULT );
    //blur( src_gray, detected_edges, Size(3,3) );

    /// Canny detector
    Canny( detected_edges, detected_edges, alpha_canny, amax_canny, 3 );
    
    /// Using Canny's output as a mask, we display our result
    grad2 = Scalar::all(0);
    src.copyTo( grad2, detected_edges);
    
    /***********/
    calcul(1);
    /**********/
    
    imshow( "Canny Demo", grad2 );
}


void filtrecanny(int, void*){
    canny();
}

//void filtre(int, void*){
//
//    scale = (double)alpha_slider ;
//    delta = (double)delta_slider;
//
//    sobel();
//    laplace();
//
//}


int main( int argc, char** argv )
{
    /// Load an image
    src = imread( argv[1] );
    src2 = imread(argv[2]);

    contours_ref = 0;
    contours_ref = detec(src2);
    cout<< "Ref " << contours_ref <<endl;

    if( !src.data )
    { return -1; }

    //void GaussianBlur(InputArray src, OutputArray dst, Size ksize, double sigmaX, double sigmaY=0, int borderType=BORDER_DEFAULT )
    GaussianBlur( src, src, Size(3,3), 0, 0, BORDER_DEFAULT );

    /// Convert it to gray
    cvtColor( src, src_gray, CV_BGR2GRAY );

    /// Sobel et Laplace
    namedWindow( "Sobel Demo", CV_WINDOW_AUTOSIZE );
    moveWindow("Sobel Demo", 10, 200);
    
    namedWindow( "Laplace Demo", CV_WINDOW_AUTOSIZE );
    moveWindow("Laplace Demo", 550, 200);
    
    namedWindow( "Trackbar Sobel & Laplace", CV_WINDOW_NORMAL );
    moveWindow("Trackbar Sobel & Laplace", 300, 150);
    
//    char TrackbarName[50];
//    sprintf( TrackbarName, "Alpha x %d", alpha_slider_max);
//    createTrackbar( TrackbarName, "Trackbar Sobel & Laplace", &alpha_slider, alpha_slider_max, filtre );
//
//    char TrackbarName1[50];
//    sprintf( TrackbarName1, "Delta x %d", delta_slider_max);
//    createTrackbar( TrackbarName1, "Trackbar Sobel & Laplace", &delta_slider, delta_slider_max, filtre );
    
    sobel();
    laplace();
    
    /// Canny
    namedWindow( "Canny Demo", CV_WINDOW_AUTOSIZE );
    moveWindow("Canny Demo", 1100, 200);
    
    namedWindow( "TrackbarCanny1", CV_WINDOW_NORMAL );
    moveWindow("TrackbarCanny1", 1300, 150);

    char TrackbarName2[50];
    sprintf( TrackbarName2, "LowThreshold x %d", alpha_canny_max );
    createTrackbar( TrackbarName2, "TrackbarCanny1", &alpha_canny, alpha_canny_max, filtrecanny );
    
    
    char TrackbarName3[50];
    sprintf( TrackbarName3, "HighThreshold x %d", amax_canny_max );
    createTrackbar( TrackbarName3, "TrackbarCanny1", &amax_canny, amax_canny_max, filtrecanny );

    
    waitKey(0);
    return 0;
}


